﻿// Todas estas variables estáticas sirven para controlar el juego.
class Snake
{

    static int width = 20;
    static int height = 20;
    static int score = 0;
    static bool gameOver = false;
    static Random random = new Random();

    // Esto implica que el juego estará en 2 dimensiones.
    static int snakeX;
    static int snakeY;
    static int fruitX;
    static int fruitY;
    // Ahora crearemos arrays para almacenar enteros
    static int[] tailX = new int[100];
    static int[] tailY = new int[100];
    static int tailLenght = 0;
    static int speed = 10;
    static int direction = 0;



    // Método principal
    static void Main()
    {
        Console.Title = "Snake Game 1.0";
        Console.CursorVisible = false;

        InitializeGame();

        while (!gameOver)
        {
            if (Console.KeyAvailable)
            {
                HandleKeypress(Console.ReadKey(true).Key);
            }

            MoveSnake();

            if (CheckCollision())
            {
                gameOver = true;
            }

            Draw();
            Thread.Sleep(1000 / speed);
        }

        Console.SetCursorPosition(width / 2 - 5, height / 2);
        Console.WriteLine("Game Over! Your score is: " + score + ".");
        Console.WriteLine("");


    }

    // Ahora a escribir el método del Draw.

    static void InitializeGame()
    {
        snakeX = width / 2;
        snakeY = height / 2;

        fruitX = random.Next(1, width - 1);
        fruitY = random.Next(1, height - 1);

        score = 0;
        direction = 0;

    }

    static void Draw()
    {
        Console.Clear();

        for (int i = 0; i < width + 2; i++)
        {
            Console.Write("#");

        }
        Console.WriteLine();
        // esta cosa hace filas y columnas
        for (int i = 0; i < height; i++)
        {
            for (int j = 0; j< width; j++)
            {
                if (j == 0)
                {
                    Console.Write("#");
                }

                else if (j == width - 1)
                {
                    Console.Write("#");
                }

                // Cuerpo de la snake.
                else if (i == snakeY && j == snakeX)
                {
                    Console.Write("O");
                }

                // Cuerpo de la fruta.
                else if (i == fruitY && j == fruitX)
                {
                    Console.Write("W");
                }

                // Si el bicle anterior no se cumple, entra en acción este else.
                else
                {
                    bool tailBit = false;
                    for (int k = 0; k < tailLenght; k++)
                    {
                        if (tailX[k] == j && tailY[k] == i)
                        {
                            tailBit = true;
                            break;
                        }
                    }
                    if (tailBit)
                    {
                        Console.Write("o");
                    }

                    else
                    {
                        Console.Write(" ");
                    }

                }
            }
            Console.WriteLine();
        }

        for (int i = 0; i < width + 2; i++)
        {
            Console.Write("#");
        }

        Console.WriteLine();
        Console.WriteLine("Score:  {0}", score);


    }

    // Este método se encarga de la pulsación de las teclas.
    static void HandleKeypress(ConsoleKey Key)
    {
        switch(Key)
        {
            case ConsoleKey.W:
            case ConsoleKey.UpArrow:
                if (direction != 2)
                {
                    direction = 0;
                }
                break;
            case ConsoleKey.D:
            case ConsoleKey.RightArrow:
                if (direction != 3)
                {
                    direction = 1;
                }
                break;
            case ConsoleKey.S:
            case ConsoleKey.DownArrow:
                if (direction != 0)
                {
                    direction = 2;
                }
                break;
            case ConsoleKey.A:
            case ConsoleKey.LeftArrow:
                if (direction != 1)
                {
                    direction = 3;
                }
                break;
            case ConsoleKey.Escape:
                gameOver = true;
                break;

        }
    }

    //Ahora se trabajará el movimiento de la serpiente.

    static void MoveSnake()
    {
        int prevX = tailX[0];
        int prevY = tailY[0];
            int prev2X, preve2Y;

        tailX[0] = snakeX;
        tailY[0] = snakeY;

        for (int i = 1; i < tailLenght; i++)
        {
            prev2X = tailX[i];
            preve2Y = tailY[i];
            tailX[i] = prevX;
            tailY[i] = prevY;
            prevX = prev2X;
            prevY = preve2Y;

        }

        switch (direction)
        {
            case 0:
                snakeY--;
                break;

            case 1:
                snakeX++;
                break;

            case 2:
                snakeY++;
                break;

            case 3:
                snakeX--;
                break;

        }

        if(snakeX == 0 || snakeX == width -1 || snakeY == 0 || snakeY == height)
        {
            gameOver = true;
        }

        if (snakeX == fruitX && snakeY == fruitY)
        {
            score += 10;
            tailLenght++;
            fruitX = random.Next(1, width - 1);
            fruitY = random.Next(1, height - 1);
        }


    }

    static bool CheckCollision()
    {
        for (int i = 0; i < tailLenght; i++)
        {
            if (tailX[i] == snakeX && tailY[i] == snakeY)
            {
                return true;
            }
        }

        return false;


    }

}