﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SistemaHotel
{
    public class Habitacion
    {
        public int Numero { get; set; }
        public string Tipo { get; set; }
        public decimal Precio { get; set; }
        public bool Disponible { get; set; }

        public void MostrarInformacion()
        {
            Console.WriteLine($"Habitación: {Numero}");
            Console.WriteLine($"Tipo: {Tipo}");
            Console.WriteLine($"Precio: {Precio}");
            Console.WriteLine($"Disponible: {Disponible}");
            Console.WriteLine("---------------------------");
        }
    }

    public class Cliente
    {
        public string Nombre { get; set; }
        public string Cedula { get; set; }
        public string Telefono { get; set; }
    }

    public class Reserva
    {
        public Cliente Cliente { get; set; }
        public Habitacion Habitacion { get; set; }
        public DateTime FechaEntrada { get; set; }
        public DateTime FechaSalida { get; set; }

        public decimal CalcularTotal()
        {
            int dias = (FechaSalida - FechaEntrada).Days;
            return dias * Habitacion.Precio;
        }

        public void MostrarReserva()
        {
            Console.WriteLine("--------------------------------");
            Console.WriteLine($"Cliente: {Cliente.Nombre}");
            Console.WriteLine($"Cédula: {Cliente.Cedula}");
            Console.WriteLine($"Teléfono: {Cliente.Telefono}");
            Console.WriteLine($"Habitación: {Habitacion.Numero}");
            Console.WriteLine($"Entrada: {FechaEntrada:dd/MM/yyyy}");
            Console.WriteLine($"Salida: {FechaSalida:dd/MM/yyyy}");
            Console.WriteLine($"Total: {CalcularTotal()}");
            Console.WriteLine("--------------------------------");
        }
    }

    public class Hotel
    {
        public List<Habitacion> Habitaciones { get; set; }
        public List<Reserva> Reservas { get; set; }

        public Hotel()
        {
            Habitaciones = new List<Habitacion>();
            Reservas = new List<Reserva>();
        }

        public void AgregarHabitacion()
        {
            try
            {
                Console.Write("Número: ");
                int numero = int.Parse(Console.ReadLine());

                if (Habitaciones.Any(h => h.Numero == numero))
                {
                    Console.WriteLine("Ya existe una habitación con ese número.");
                    return;
                }

                Console.Write("Tipo: ");
                string tipo = Console.ReadLine();

                Console.Write("Precio: ");
                decimal precio = decimal.Parse(Console.ReadLine());

                Habitacion habitacion = new Habitacion()
                {
                    Numero = numero,
                    Tipo = tipo,
                    Precio = precio,
                    Disponible = true
                };

                Habitaciones.Add(habitacion);

                Console.WriteLine("Habitación registrada.");
            }
            catch (FormatException)
            {
                Console.WriteLine("Error: dato numérico inválido.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("Proceso finalizado.");
            }
        }

        public void MostrarHabitacionesDisponibles()
        {
            var disponibles = Habitaciones.Where(h => h.Disponible);

            foreach (var h in disponibles)
            {
                h.MostrarInformacion();
            }
        }

        public void CrearReserva()
        {
            try
            {
                Console.Write("Nombre: ");
                string nombre = Console.ReadLine();

                Console.Write("Cédula: ");
                string cedula = Console.ReadLine();

                Console.Write("Teléfono: ");
                string telefono = Console.ReadLine();

                Console.Write("Número habitación: ");
                int numero = int.Parse(Console.ReadLine());

                Habitacion habitacion =
                    Habitaciones.FirstOrDefault(h => h.Numero == numero);

                if (habitacion == null)
                {
                    Console.WriteLine("Habitación no encontrada.");
                    return;
                }

                if (!habitacion.Disponible)
                {
                    Console.WriteLine("La habitación está ocupada.");
                    return;
                }

                Console.Write("Fecha entrada (dd/MM/yyyy): ");
                DateTime entrada =
                    DateTime.Parse(Console.ReadLine());

                Console.Write("Fecha salida (dd/MM/yyyy): ");
                DateTime salida =
                    DateTime.Parse(Console.ReadLine());

                if (salida <= entrada)
                {
                    Console.WriteLine("Fecha inválida.");
                    return;
                }

                Cliente cliente = new Cliente()
                {
                    Nombre = nombre,
                    Cedula = cedula,
                    Telefono = telefono
                };

                Reserva reserva = new Reserva()
                {
                    Cliente = cliente,
                    Habitacion = habitacion,
                    FechaEntrada = entrada,
                    FechaSalida = salida
                };

                Reservas.Add(reserva);

                habitacion.Disponible = false;

                Console.WriteLine("Reserva creada exitosamente.");
            }
            catch (FormatException)
            {
                Console.WriteLine("Error de formato.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Operación terminada.");
            }
        }

        public void CancelarReserva()
        {
            try
            {
                Console.Write("Número de habitación: ");
                int numero = int.Parse(Console.ReadLine());

                Reserva reserva =
                    Reservas.FirstOrDefault(r =>
                    r.Habitacion.Numero == numero);

                if (reserva == null)
                {
                    Console.WriteLine("Reserva no encontrada.");
                    return;
                }

                reserva.Habitacion.Disponible = true;

                Reservas.Remove(reserva);

                Console.WriteLine("Reserva cancelada.");
            }
            catch (FormatException)
            {
                Console.WriteLine("Número inválido.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Proceso finalizado.");
            }
        }

        public void MostrarReservas()
        {
            foreach (var r in Reservas)
            {
                r.MostrarReserva();
            }
        }

        public void GuardarHabitacionesTXT()
        {
            try
            {
                using (StreamWriter sw =
                       new StreamWriter("habitaciones.txt"))
                {
                    foreach (var h in Habitaciones)
                    {
                        sw.WriteLine(
                            $"{h.Numero},{h.Tipo},{h.Precio},{h.Disponible}");
                    }
                }

                Console.WriteLine("Habitaciones guardadas.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Guardado finalizado.");
            }
        }

        public void CargarHabitacionesTXT()
        {
            try
            {
                Habitaciones.Clear();

                string[] lineas =
                    File.ReadAllLines("habitaciones.txt");

                foreach (string linea in lineas)
                {
                    string[] datos = linea.Split(',');

                    Habitaciones.Add(new Habitacion()
                    {
                        Numero = int.Parse(datos[0]),
                        Tipo = datos[1],
                        Precio = decimal.Parse(datos[2]),
                        Disponible = bool.Parse(datos[3])
                    });
                }

                Console.WriteLine("Habitaciones cargadas.");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("No existe habitaciones.txt");
            }
            catch (FormatException)
            {
                Console.WriteLine("Error de formato en archivo.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Carga finalizada.");
            }
        }

        public void GuardarReservasTXT()
        {
            try
            {
                using (StreamWriter sw =
                       new StreamWriter("reservas.txt"))
                {
                    foreach (var r in Reservas)
                    {
                        sw.WriteLine(
                            $"{r.Cliente.Nombre}," +
                            $"{r.Cliente.Cedula}," +
                            $"{r.Cliente.Telefono}," +
                            $"{r.Habitacion.Numero}," +
                            $"{r.FechaEntrada:yyyy-MM-dd}," +
                            $"{r.FechaSalida:yyyy-MM-dd}");
                    }
                }

                Console.WriteLine("Reservas guardadas.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Guardado finalizado.");
            }
        }

        public void CargarReservasTXT()
        {
            try
            {
                Reservas.Clear();

                string[] lineas =
                    File.ReadAllLines("reservas.txt");

                foreach (string linea in lineas)
                {
                    string[] datos = linea.Split(',');

                    int numeroHab = int.Parse(datos[3]);

                    Habitacion habitacion =
                        Habitaciones.FirstOrDefault(
                            h => h.Numero == numeroHab);

                    if (habitacion != null)
                    {
                        habitacion.Disponible = false;

                        Cliente cliente = new Cliente()
                        {
                            Nombre = datos[0],
                            Cedula = datos[1],
                            Telefono = datos[2]
                        };

                        Reserva reserva = new Reserva()
                        {
                            Cliente = cliente,
                            Habitacion = habitacion,
                            FechaEntrada =
                                DateTime.Parse(datos[4]),
                            FechaSalida =
                                DateTime.Parse(datos[5])
                        };

                        Reservas.Add(reserva);
                    }
                }

                Console.WriteLine("Reservas cargadas.");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("No existe reservas.txt");
            }
            catch (FormatException)
            {
                Console.WriteLine("Error de formato.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Carga finalizada.");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Hotel hotel = new Hotel();

            int opcion = 0;

            do
            {
                Console.WriteLine("\n===== SISTEMA HOTEL =====");
                Console.WriteLine("1. Registrar habitación");
                Console.WriteLine("2. Mostrar habitaciones disponibles");
                Console.WriteLine("3. Crear reserva");
                Console.WriteLine("4. Cancelar reserva");
                Console.WriteLine("5. Guardar datos");
                Console.WriteLine("6. Cargar datos");
                Console.WriteLine("7. Mostrar reservas");
                Console.WriteLine("8. Salir");

                Console.Write("Seleccione una opción: ");

                try
                {
                    opcion = int.Parse(Console.ReadLine());

                    switch (opcion)
                    {
                        case 1:
                            hotel.AgregarHabitacion();
                            break;

                        case 2:
                            hotel.MostrarHabitacionesDisponibles();
                            break;

                        case 3:
                            hotel.CrearReserva();
                            break;

                        case 4:
                            hotel.CancelarReserva();
                            break;

                        case 5:
                            hotel.GuardarHabitacionesTXT();
                            hotel.GuardarReservasTXT();
                            break;

                        case 6:
                            hotel.CargarHabitacionesTXT();
                            hotel.CargarReservasTXT();
                            break;

                        case 7:
                            hotel.MostrarReservas();
                            break;

                        case 8:
                            Console.WriteLine("Saliendo...");
                            break;

                        default:
                            Console.WriteLine("Opción inválida.");
                            break;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Debe ingresar un número.");
                }

            } while (opcion != 8);
        }
    }
}