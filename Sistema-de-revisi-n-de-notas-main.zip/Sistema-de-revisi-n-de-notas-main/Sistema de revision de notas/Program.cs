﻿// LISTAS PARA GUARDAR DATOS

List<string> nombres = new List<string>();
List<string> apellidos = new List<string>();
List<double> promedios = new List<double>();
List<string> literales = new List<string>();

// VARIABLE PARA CONTINUAR

string continuar = "s";

// CONTADOR DE ESTUDIANTES

int contador = 0;

// BUCLE PRINCIPAL

while (continuar == "s" && contador < 15)
{
    // Declarar la variable nombre.

    string nombre;

    // Declarar la variable apellido.

    string apellido;

    // Apartado de solicitación de datos.

    Console.Write("Ingrese su nombre: ");
    nombre = Console.ReadLine();

    Console.Write("Ingrese su apellido: ");
    apellido = Console.ReadLine();

    // Solicitar y mostrar notas a revisar.

    Console.Write("Ingrese nota1: ");
    double nota1 = Convert.ToDouble(Console.ReadLine());

    Console.Write("Ingrese nota2: ");
    double nota2 = Convert.ToDouble(Console.ReadLine());

    Console.Write("Ingrese nota3: ");
    double nota3 = Convert.ToDouble(Console.ReadLine());

    Console.Write("Ingrese nota4: ");
    double nota4 = Convert.ToDouble(Console.ReadLine());

    Console.WriteLine("Nombre: " + nombre);
    Console.WriteLine("Apellido: " + apellido);

    // Solicita el promedio.

    double promedio;

    promedio = (nota1 + nota2 + nota3 + nota4) / 4;

    Console.WriteLine("Promedio: " + promedio);

    // Aplicación de las literales.

    string literal;

    if (promedio >= 90)
    {
        literal = "A";
    }
    else if (promedio >= 80)
    {
        literal = "B";
    }
    else if (promedio >= 70)
    {
        literal = "C";
    }
    else if (promedio >= 60)
    {
        literal = "D";
    }
    else
    {
        literal = "F";
    }

    Console.WriteLine("Literal: " + literal);

    // GUARDAR DATOS EN LAS LISTAS

    nombres.Add(nombre);

    apellidos.Add(apellido);

    promedios.Add(promedio);

    literales.Add(literal);

    // AUMENTAR CONTADOR

    contador++;

    // PREGUNTAR SI DESEA CONTINUAR

    if (contador < 15)
    {
        Console.Write("\n¿Desea continuar? (s/n): ");

        continuar = Console.ReadLine().ToLower();
    }
    else
    {
        Console.WriteLine("\nSe alcanzó el límite máximo de 15 estudiantes.");
    }
}

// MOSTRAR TODOS LOS ESTUDIANTES REGISTRADOS

Console.WriteLine("\n===== LISTA FINAL DE ESTUDIANTES =====");

for (int i = 0; i < nombres.Count; i++)
{
    Console.WriteLine("\nEstudiante #" + (i + 1));

    Console.WriteLine("Nombre: " + nombres[i]);

    Console.WriteLine("Apellido: " + apellidos[i]);

    Console.WriteLine("Promedio: " + promedios[i]);

    Console.WriteLine("Literal: " + literales[i]);
}

Console.WriteLine("\nPrograma finalizado.");

Console.ReadKey();