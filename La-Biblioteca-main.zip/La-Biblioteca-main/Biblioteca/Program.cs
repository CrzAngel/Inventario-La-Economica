﻿using System;
using System.Collections.Generic;

class Libro
{
    public string Titulo { get; set; }
    public string Autor { get; set; }
    public string ISBN { get; set; }
    public bool Disponible { get; set; }
    public DateTime FechaPrestamo { get; set; }

    public Libro(string titulo, string autor, string isbn)
    {
        Titulo = titulo;
        Autor = autor;
        ISBN = isbn;
        Disponible = true;
    }

    public void MostrarInformacion()
    {
        Console.WriteLine("Título: " + Titulo);
        Console.WriteLine("Autor: " + Autor);
        Console.WriteLine("ISBN: " + ISBN);
        Console.WriteLine("Disponible: " + Disponible);
    }

    public void PrestarLibro()
    {
        Disponible = false;
        FechaPrestamo = DateTime.Now;
    }

    public void DevolverLibro()
    {
        Disponible = true;
    }
}

class Usuario
{
    public string Nombre { get; set; }
    public string Cedula { get; set; }
    public List<Libro> LibrosPrestados { get; set; }

    public Usuario(string nombre, string cedula)
    {
        Nombre = nombre;
        Cedula = cedula;
        LibrosPrestados = new List<Libro>();
    }

    public void TomarPrestado(Libro libro)
    {
        if (LibrosPrestados.Count >= 3)
        {
            Console.WriteLine("Máximo de libros alcanzado.");
            return;
        }

        if (libro.Disponible)
        {
            LibrosPrestados.Add(libro);
            libro.PrestarLibro();
            Console.WriteLine("Libro prestado correctamente.");
        }
        else
        {
            Console.WriteLine("El libro no está disponible.");
        }
    }

    public void DevolverLibro(Libro libro)
    {
        if (LibrosPrestados.Contains(libro))
        {
            LibrosPrestados.Remove(libro);
            libro.DevolverLibro();
            Console.WriteLine("Libro devuelto correctamente.");
        }
    }

    public void MostrarLibrosPrestados()
    {
        Console.WriteLine("\nLibros de " + Nombre);
        foreach (var l in LibrosPrestados)
        {
            Console.WriteLine("- " + l.Titulo);
        }
    }

    public double CalcularMulta()
    {
        double multa = 0;

        foreach (var libro in LibrosPrestados)
        {
            TimeSpan dias = DateTime.Now - libro.FechaPrestamo;

            if (dias.Days > 7)
            {
                multa += (dias.Days - 7) * 10;
            }
        }

        return multa;
    }

    public void MostrarMulta()
    {
        Console.WriteLine("Multa total: RD$" + CalcularMulta());
    }
}

class Biblioteca
{
    public List<Libro> Libros { get; set; }
    public List<Usuario> Usuarios { get; set; }

    public Biblioteca()
    {
        Libros = new List<Libro>();
        Usuarios = new List<Usuario>();
    }

    public void AgregarLibro(Libro libro)
    {
        Libros.Add(libro);
    }

    public void RegistrarUsuario(Usuario usuario)
    {
        Usuarios.Add(usuario);
    }

    public Libro BuscarLibro(string isbn)
    {
        foreach (var libro in Libros)
        {
            if (libro.ISBN == isbn)
                return libro;
        }
        return null;
    }

    public Usuario BuscarUsuario(string cedula)
    {
        foreach (var usuario in Usuarios)
        {
            if (usuario.Cedula == cedula)
                return usuario;
        }
        return null;
    }

    public void MostrarLibrosDisponibles()
    {
        Console.WriteLine("\n===== LIBROS DISPONIBLES =====");

        foreach (var libro in Libros)
        {
            if (libro.Disponible)
            {
                libro.MostrarInformacion();
                Console.WriteLine();
            }
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Biblioteca biblioteca = new Biblioteca();
        bool salir = false;

        while (!salir)
        {
            Console.WriteLine("\n===== BIBLIOTECA =====");
            Console.WriteLine("1. Registrar libro");
            Console.WriteLine("2. Registrar usuario");
            Console.WriteLine("3. Prestar libro");
            Console.WriteLine("4. Devolver libro");
            Console.WriteLine("5. Mostrar libros disponibles");
            Console.WriteLine("6. Mostrar multa");
            Console.WriteLine("7. Salir");

            Console.Write("Opción: ");
            int opcion = Convert.ToInt32(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.Write("Título: ");
                    string titulo = Console.ReadLine();
                    Console.Write("Autor: ");
                    string autor = Console.ReadLine();
                    Console.Write("ISBN: ");
                    string isbn = Console.ReadLine();

                    biblioteca.AgregarLibro(new Libro(titulo, autor, isbn));
                    break;

                case 2:
                    Console.Write("Nombre: ");
                    string nombre = Console.ReadLine();
                    Console.Write("Cédula: ");
                    string cedula = Console.ReadLine();

                    biblioteca.RegistrarUsuario(new Usuario(nombre, cedula));
                    break;

                case 3:
                    Console.Write("Cédula: ");
                    string c1 = Console.ReadLine();
                    Usuario u1 = biblioteca.BuscarUsuario(c1);

                    Console.Write("ISBN: ");
                    string i1 = Console.ReadLine();
                    Libro l1 = biblioteca.BuscarLibro(i1);

                    if (u1 != null && l1 != null)
                        u1.TomarPrestado(l1);
                    break;

                case 4:
                    Console.Write("Cédula: ");
                    string c2 = Console.ReadLine();
                    Usuario u2 = biblioteca.BuscarUsuario(c2);

                    Console.Write("ISBN: ");
                    string i2 = Console.ReadLine();
                    Libro l2 = biblioteca.BuscarLibro(i2);

                    if (u2 != null && l2 != null)
                        u2.DevolverLibro(l2);
                    break;

                case 5:
                    biblioteca.MostrarLibrosDisponibles();
                    break;

                case 6:
                    Console.Write("Cédula: ");
                    string c3 = Console.ReadLine();
                    Usuario u3 = biblioteca.BuscarUsuario(c3);

                    if (u3 != null)
                        u3.MostrarMulta();
                    break;

                case 7:
                    salir = true;
                    break;
            }
        }
    }
}